insert into orders 
(id, product_code, product_size, quantity, o_seq)
values('one', 'hi0001', '230', '2', ORDER_SEQ.nextval);

insert into orders 
(id, product_code, product_size, quantity, o_seq)
values('one', 'bt0001', '235', '5', ORDER_SEQ.nextval);