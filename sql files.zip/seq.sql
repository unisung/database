CREATE SEQUENCE ORDER_SEQ
                START WITH 1 
                INCREMENT BY 1 
                MAXVALUE 100000 ;